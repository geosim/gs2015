// MENU.h : file di intestazione principale per la DLL MENU
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// simboli principali


// CMENUApp
// Vedere MENU.cpp per l'implementazione di questa classe
//

class CMENUApp : public CWinApp
{
public:
	CMENUApp();

// Override
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};
