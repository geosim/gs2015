//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MENU.rc
//
#define IDB_BITMAP1                     22137
#define IDB_BITMAP2                     22138
#define IDB_BITMAP3                     22149
#define IDB_BITMAP4                     22152

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        22153
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         22000
#define _APS_NEXT_SYMED_VALUE           22000
#endif
#endif
