// MENU.cpp : definisce le routine di inizializzazione per la DLL.
//

#include "stdafx.h"
#include "MENU.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//
//	Nota
//
//		Se questa DLL � collegata in modo dinamico alle DLL
//		MFC, le funzioni esportate da questa DLL che
//		vengono chiamate in MFC devono avere la macro AFX_MANAGE_STATE
//		all'inizio della funzione.
//
//		Ad esempio:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		� molto importante che tale macro sia presente in ciascuna
//		funzione davanti a qualsiasi chiamata MFC. Tale macro dovr�
//		quindi comparire come la prima istruzione all'interno della 
//		funzione, precedendo anche le dichiarazioni di variabili oggetto,
//		poich� i relativi costruttori possono generare chiamate alla DLL
//		MFC.
//
//		Vedere le note tecniche 33 e 58 di MFC per ulteriori
//		informazioni.
//

// CMENUApp

BEGIN_MESSAGE_MAP(CMENUApp, CWinApp)
END_MESSAGE_MAP()


// Costruzione di CMENUApp

CMENUApp::CMENUApp()
{
	// TODO: aggiungere qui il codice di costruzione.
	// Inserire l'inizializzazione significativa in InitInstance
}


// L'unico oggetto CMENUApp

CMENUApp theApp;


// Inizializzazione di CMENUApp

BOOL CMENUApp::InitInstance()
{
	CWinApp::InitInstance();

	return TRUE;
}
